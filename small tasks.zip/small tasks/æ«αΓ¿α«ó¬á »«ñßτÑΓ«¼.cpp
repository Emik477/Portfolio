/*����������� ���������� ��������� �������������� �������*/
#include <iostream>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    FILE* fin, * fout;

    if (argc == 3) 
    {
        fin = fopen( argv[1], "r");
        fout = fopen( argv[2], "w");
    
        if ( fin && fout )
        {
        	long long int size = 0,  i = 0, j = 0, k = 0, size_b = 0;

        	if( fscanf( fin, "%lld", &size ) > 0 )
        	{
        		long long int min = 0, max = 0, *arr;
        		arr = (long long int*)malloc( size*sizeof(long long int) );
        		
        		while( fscanf( fin, "%lld", &arr[i] ) > 0 )
        		{
        			if( i == size ) break;	
        			i++;
				}
        		if( i < size )
				{
        			size = i;
        			arr = (long long int*)realloc(arr,(size)*sizeof(long long int));
				} 
        		min = arr[0];
        		max = arr[0];
        		for( i = 0; i < size; i++ )	
				{
					if( arr[i] < min ) min = arr[i];
					if( arr[i] > max ) max = arr[i];
        		}
        		size_b = abs(max) + abs(min) + 1; 
        		
        		long long int b[size_b];	
        		for(  j = 0; j < size_b; j++ ) b[j] = 0;
        		for( i = 0; i < size; i++ )
        		{	
        			j = arr[i] + abs(min);
        			b[j] = b[j] + 1;
				}
				
        		for( i = 0; i < size; i++ )
        		{	
        			for( j = 0; j < size_b; j++ )
        			{
        				if( b[j] > 0 ) 
        				{
        					arr[i] = j - abs(min);
        					b[j] = b[j] - 1;
        					break;
						}
					}
        		}
        		fprintf(fout, "%lld ", size);
        		for( i = 0; i < size; i++ ) fprintf(fout, "%lld ", arr[i]);
			}
		}	
	}
    else return 0;
}
