#include <stdio.h>
#include <stdlib.h>

void Subsets(int num, const char *file_in ,const char *file_out)
{	
    FILE* fin, * fout;
    fin = fopen( file_in, "r");
    fout = fopen( file_out, "w");
    
	int m = 0, a = num - 1;
	for ( m = 0; m < ( 1<<num ); m++ ) 
	{
		for ( a = num - 1 ; a >= 0; a-- ) 
		{
			if ( m & ( 1<<a ) ) fprintf( fout, "%d ", a + 1 );
			else  fprintf( fout, "0 " );
		}
		fprintf( fout, "\n" );
	}		
}

int main(int argc, char* argv[])
{
    FILE* fin, * fout;
    
    if (argc == 3) 
    {
        fin = fopen( argv[1], "r");
        fout = fopen( argv[2], "w");
        if ( fin && fout )
        {	
        	int num = 0;
    		if ( fscanf( fin,"%d", &num ) != 0 ) 
    		{
    			Subsets( num, argv[1], argv[2] );
    			return 0;
        	}	
    	}
	}
    else return 0;
}

