import random, pygame, time
from env_game_env import GameEnv

env = GameEnv()
state = env.reset()

for _ in range(200):               # 200 шагов для теста
    action = random.randint(0, 3)  # случайное действие
    state, _, done, _ = env.step(action)
    env.render()
    if done:
        break
    time.sleep(0.05)
    print(f"PAC  : {env.logic.get_player_pos()}")
    for i, g in enumerate(env.logic.ghosts):
        print(f"GHOST{i}:{(g['x'], g['y'])}")
    # чтобы глазами увидеть движение
pygame.quit()
