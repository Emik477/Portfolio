"""dqn_agent_train.py — обучение DQN‑агента играть в Pac‑Man
================================================================
Этот скрипт запускает процесс reinforcement‑learning:
1. Создаёт окружение `GameEnv` (нашей игры Pac‑Man);
2. Инициализирует нейросеть — аппроксиматор Q‑функции;
3. В цикле эпизодов собирает опыт, тренируется, логирует статистику
   и периодически сохраняет модель.
"""

# ──────────────────────────── Импорты ────────────────────────────
import torch
import torch.nn as nn
import torch.optim as optim
import random
import numpy as np
from collections import deque
from env_game_env import GameEnv
import os, csv, time

# ────────────────────── Файл для CSV‑логирования ──────────────────
ts = time.strftime("%Y%m%d_%H%M")                  # метка времени
log_csv = open(f"train_log_{ts}.csv", "w", newline="", encoding="utf-8")
writer = csv.writer(log_csv, delimiter=';')
writer.writerow(["episode", "steps", "total_reward", "epsilon"])

# ───────────────────────── Hyper‑параметры ────────────────────────
GAMMA           = 0.99      # коэффициент дисконтирования (важность будущих наград)
LR              = 1e-4      # скорость обучения Adam‑оптимизатора
BATCH_SIZE      = 64        # сколько переходов берём из буфера за один train‑шаг
MEMORY_SIZE     = 10_000    # размер experience replay (deque)
EPSILON_START   = 1.0       # вероятность случайного действия в самом начале
EPSILON_END     = 0.1       # минимальная ε, до которой мы «спускаемся»
EPSILON_DECAY   = 0.995     # множитель ε на каждом *эпизоде*
TARGET_UPDATE   = 10        # раз в N эпизодов копируем веса в target‑сеть
MODEL_PATH      = "pacman_dqn_model.pt"  # файл чек‑пойнта

# ────────────────────────── Модель Q‑сети ─────────────────────────
class DQN(nn.Module):
    """Простая полносвязная сеть: 2 скрытых слоя × 128 нейронов."""
    def __init__(self, input_dim: int, output_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 128)
        self.out = nn.Linear(128, output_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.out(x)              # Q‑значения для всех действий

# ──────────────────────────── Агент ───────────────────────────────
class Agent:
    """Инкапсулирует политику, буфер опыта и всю логику обучения."""
    def __init__(self, state_dim: int, action_dim: int):
        # «policy_net» — обновляется каждую итерацию; «target_net» — стабильная копия.
        self.policy_net = DQN(state_dim, action_dim)
        self.target_net = DQN(state_dim, action_dim)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=LR)

        self.memory   = deque(maxlen=MEMORY_SIZE)  # experience replay
        self.epsilon  = EPSILON_START              # текущая ε
        self.action_dim = action_dim

        # Если на диске уже есть сохранённые веса — загружаем их.
        if os.path.exists(MODEL_PATH):
            self.load_model()

    # ε‑greedy выбор действия
    def select_action(self, state: np.ndarray) -> int:
        if random.random() < self.epsilon:
            return random.randrange(self.action_dim)   # случайный ход
        with torch.no_grad():
            q_vals = self.policy_net(torch.FloatTensor(state).unsqueeze(0))
            return int(q_vals.argmax().item())         # argmax Q(s,·)

    # Сохраняем переход (s, a, r, s', done) в буфер
    def store(self, transition):
        self.memory.append(transition)

    # Один шаг градиентного спуска по мини‑батчу из буфера
    def train_step(self):
        if len(self.memory) < BATCH_SIZE:
            return  # ждём, пока буфер наполнится
        # случайная выборка без повторений
        batch = random.sample(self.memory, BATCH_SIZE)
        states, actions, rewards, next_states, dones = zip(*batch)

        # Приводим к тензорам PyTorch
        states      = torch.FloatTensor(states)
        actions     = torch.LongTensor(actions).unsqueeze(1)
        rewards     = torch.FloatTensor(rewards).unsqueeze(1)
        next_states = torch.FloatTensor(next_states)
        dones       = torch.FloatTensor(dones).unsqueeze(1)

        # Q(s,a) для взятых действий
        q_values = self.policy_net(states).gather(1, actions)
        # max_a' Q_target(s', a')
        with torch.no_grad():
            next_max = self.target_net(next_states).max(1)[0].unsqueeze(1)
            targets = rewards + GAMMA * next_max * (1 - dones)

        # MSE‑потеря
        loss = nn.MSELoss()(q_values, targets)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

    # Копируем параметры из policy‑ в target‑сеть
    def update_target(self):
        self.target_net.load_state_dict(self.policy_net.state_dict())

    # Серилизация модели
    def save_model(self):
        torch.save(self.policy_net.state_dict(), MODEL_PATH)

    def load_model(self):
        self.policy_net.load_state_dict(torch.load(MODEL_PATH))
        self.target_net.load_state_dict(self.policy_net.state_dict())
        print("[INFO] Model loaded from", MODEL_PATH)

# ───────────────────────── Цикл обучения ──────────────────────────
if __name__ == "__main__":
    env = GameEnv()                       # создаём игровое окружение
    state_dim  = len(env.get_state())     # размер вектора состояния (15)
    action_dim = 4                        # действия: R, L, U, D
    agent = Agent(state_dim, action_dim)

    EPISODES = 1_000                      # сколько эпизодов сыграть

    for episode in range(EPISODES):
        state = env.reset()               # вернуть игру в начальное состояние
        total_reward = 0.0
        done = False
        frame_idx = 0                     # счётчик шагов в эпизоде

        while not done:
            action = agent.select_action(state)

            # «frame‑skip = 4»: повторяем выбранное действие 4 кадра среды.
            reward_acc = 0.0
            for _ in range(4):
                next_state, r, done, _ = env.step(action)
                reward_acc += r
                frame_idx += 1
                if done:
                    break

            # кладём переход в буфер, учимся
            agent.store((state, action, reward_acc, next_state, done))
            agent.train_step()

            state = next_state
            total_reward += reward_acc

            # Рендерим окно игры лишь раз в 100 кадров, чтобы не тормозить обучение
            if frame_idx % 50 == 0:
                env.render()

            # Защита от «бесконечного» уровня: обрываем, если 6000 кадров
            if frame_idx >= 6_000:
                total_reward -= 200  # небольшой штраф
                break

        # ─── Конец эпизода ───
        # Экспоненциальное убывание ε
        agent.epsilon = max(EPSILON_END, agent.epsilon * EPSILON_DECAY)

        # Периодически синхронизируем target‑сеть и сохраняем чек‑пойнт
        if episode % TARGET_UPDATE == 0:
            agent.update_target()
            agent.save_model()
            print(f"[CHECKPOINT] Weights saved at episode {episode}")

        # Печать статистики + запись в CSV
        print(f"Episode {episode:4d} | reward {total_reward:8.2f} | ε {agent.epsilon:5.3f} | steps {frame_idx}")
        writer.writerow([episode, frame_idx, round(total_reward, 2), round(agent.epsilon, 3)])
        log_csv.flush()  # «сбросить» буфер на диск

    # Финальные действия после цикла обучения
    agent.save_model()
    log_csv.close()
    env.close()
    print("[DONE] Training complete!")
