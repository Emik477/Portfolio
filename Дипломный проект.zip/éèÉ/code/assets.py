import pygame
from pathlib import Path

# Папка со спрайтами
IMG_DIR = Path(r"D:/пакман на питоне/ВКР/img")

# Игрок (4‑кадровая анимация)
player_frames = [
    pygame.transform.scale(pygame.image.load(str(IMG_DIR / f"{i}.png")), (45, 45))
    for i in range(1, 5)
]

# Изображения призраков и состояние
red_img     = pygame.transform.scale(pygame.image.load(str(IMG_DIR / "red.png")),    (45, 45))
green_img   = pygame.transform.scale(pygame.image.load(str(IMG_DIR / "green.png")),  (45, 45))
blue_img    = pygame.transform.scale(pygame.image.load(str(IMG_DIR / "blue.png")), (45, 45))
spooked_img = pygame.transform.scale(pygame.image.load(str(IMG_DIR / "powerup.png")), (45, 45))
dead_img    = pygame.transform.scale(pygame.image.load(str(IMG_DIR / "dead.png")),    (45, 45))

ghost_imgs = {
    "red":     red_img,
    "green":   green_img,
    "blue": blue_img,
    "spooked": spooked_img,
    "dead":    dead_img,
}

# Цвет для UI
UI_CYAN = (0, 230, 252)
