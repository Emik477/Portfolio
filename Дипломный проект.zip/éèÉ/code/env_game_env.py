import pygame
import numpy as np
from game_logic import GameLogic
from assets import player_frames, ghost_imgs, UI_CYAN

class GameEnv:
    def __init__(self):
        pygame.init()
        self.WIDTH, self.HEIGHT = 900, 950
        self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        self.clock = pygame.time.Clock()
        self.logic = GameLogic()
        self.reset()

    def reset(self):
        # Сбрасываем игровую логику и фрейм-счётчик
        state = self.logic.reset()
        self.done = False
        self._frame_counter = 0

        # Авто-спавн двух призраков в свободных верхних углах
        lvl = self.logic.level
        rows, cols = len(lvl), len(lvl[0])
        num1 = int((self.HEIGHT - 50) // rows)
        num2 = int(self.WIDTH // cols)

        # 1) Левая-верхняя свободная клетка
        x_left = y_left = None
        for r in range(rows):
            for c in range(cols):
                if lvl[r][c] < 3:
                    x_left = c * num2 + (num2 - 45) / 2
                    y_left = r * num1 + (num1 - 45) / 2
                    break
            if x_left is not None:
                break

        # 2) Правая-верхняя свободная клетка
        x_right = y_right = None
        for r in range(rows):
            for c in range(cols - 1, -1, -1):
                if lvl[r][c] < 3:
                    x_right = c * num2 + (num2 - 45) / 2
                    y_right = r * num1 + (num1 - 45) / 2
                    break
            if x_right is not None:
                break
        x_br = y_br = None
        r, c = 17, 22
        x_br = c * num2 + (num2 - 45) / 2
        y_br = r * num1 + (num1 - 45) / 2
        #for r in range(rows - 1, -1, -1):  # снизу вверх
            #for c in range(cols - 1, -1, -1):  # справа влево
                #if lvl[r][c] < 3:
                   # x_br = c * num2 + (num2 - 45) / 2
                  #  y_br = r * num1 + (num1 - 45) / 2
                 #   break
            #if x_br is not None:
               # break

        # Применяем спавн прямо в GameLogic
        # индекс 0 — красный, 1 — зелёный
        self.logic.ghosts[0]['x'], self.logic.ghosts[0]['y'] = x_right, y_right
        self.logic.ghosts[1]['x'], self.logic.ghosts[1]['y'] = x_left,  y_left
        self.logic.ghosts[2]['x'], self.logic.ghosts[2]['y'] = x_br, y_br
        return np.array(state, dtype=np.float32)

    def get_state(self):
        return np.array(self.logic.get_state(), dtype=np.float32)

    def step(self, action):
        state, reward, done = self.logic.step(action)
        self.done = done
        return np.array(state, dtype=np.float32), reward, done, {}

    def render(self):
        self._frame_counter += 1

        # 1) карта (стены, точки, бонусы)
        self.logic.render(self.screen, self._frame_counter)

        # 2) Pac-Man
        px, py = self.logic.get_player_pos()
        frame = player_frames[(self._frame_counter // 5) % len(player_frames)]
        dir = self.logic.direction
        if dir == 1:
            frame = pygame.transform.flip(frame, True, False)
        elif dir == 2:
            frame = pygame.transform.rotate(frame, 90)
        elif dir == 3:
            frame = pygame.transform.rotate(frame, 270)
        self.screen.blit(frame, (px, py))

        # 3) призраки из логики
        for idx, g in enumerate(self.logic.ghosts):
            name = ("red", "green", "blue")[idx]
            self.screen.blit(ghost_imgs[name], (g['x'], g['y']))

        # 4) UI (очки и жизнь)
        font = pygame.font.SysFont('freesansbold', 20)
        score_text = font.render(f'Очки: {self.logic.score}', True, UI_CYAN)
        self.screen.blit(score_text, (10, 920))
        life_img = pygame.transform.scale(player_frames[0], (30, 30))
        self.screen.blit(life_img, (650, 915))

        pygame.display.flip()
        self.clock.tick(60)