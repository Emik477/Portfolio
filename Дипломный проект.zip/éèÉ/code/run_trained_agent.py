import torch
import pygame
import numpy as np
import time
import imageio
from env_game_env import GameEnv
from dqn_agent_train import DQN, MODEL_PATH

class TrainedAgent:
    def __init__(self, state_dim, action_dim):
        self.model = DQN(state_dim, action_dim)
        self.model.load_state_dict(torch.load(MODEL_PATH))
        self.model.eval()

    def select_action(self, state):
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0)
            q_values = self.model(state_tensor)
            return q_values.argmax().item()

if __name__ == "__main__":
    pygame.init()
    env = GameEnv()
    state_dim = len(env.get_state())
    action_dim = 4
    agent = TrainedAgent(state_dim, action_dim)
    clock = pygame.time.Clock()

    episodes = 1  # записываем одно видео
    for ep in range(episodes):
        state = env.reset()
        total_reward = 0
        done = False
        frames = []

        while not done:
            action = agent.select_action(state)
            next_state, reward, done, _ = env.step(action)
            state = next_state
            total_reward += reward

            env.render()
            pygame.display.flip()

            # захват кадра
            surface = pygame.display.get_surface()
            if surface:  # проверяем, что поверхность активна
                frame = surface.copy()
                frame_np = pygame.surfarray.array3d(frame)
                frame_np = np.transpose(frame_np, (1, 0, 2))
                frames.append(frame_np)

            clock.tick(30)  # ограничиваем до 30 FPS

        print(f"Episode {ep+1} finished with reward: {total_reward}")

        # сохранить gif
        output_path = f"trained_agent_run_episode{ep+1}.gif"
        if frames:
            imageio.mimsave(output_path, frames, fps=30)
            print(f"✅ GIF saved to {output_path}")
        else:
            print("⚠️ GIF not saved: no frames captured!")

