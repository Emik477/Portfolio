import pygame
import math
import copy
import random
from borders import borders

class GameLogic:

    def __init__(self):
        # экран и карта
        self.WIDTH, self.HEIGHT = 900, 950
        self.level = copy.deepcopy(borders)
        self.rows, self.cols = len(self.level), len(self.level[0])
        self.cell_w = self.WIDTH / self.cols
        self.cell_h = (self.HEIGHT - 50) / self.rows
        self.stuck_counter = 0
        # Помещаем Pac-Man в свободную клетку центра снизу
        lvl = self.level
        rows, cols = self.rows, self.cols
        num1 = int((self.HEIGHT - 50) // rows)
        num2 = int(self.WIDTH // cols)

        # центр поля по столбцам
        c_mid = cols // 2

        # ищем ближайшую снизу свободную строку в этом столбце
        start_row = None
        for r in range(rows - 1, -1, -1):
            if lvl[r][c_mid] < 3:
                start_row = r
                break

        # центрируем спрайт по клетке
        if start_row is not None:
            x0 = c_mid * num2 + (num2 - 45) / 2
            y0 = start_row * num1 + (num1 - 45) / 2
        else:
            x0, y0 = 450, 663  # fallback

        self.player = {'x': x0, 'y': y0, 'dir': 0, 'speed': 2}
        self.direction = 0
        self.direction = self.player['dir']
        # Три призрака
        self.ghosts =[
            {'x': self.WIDTH - 50, 'y': 50,  'dir': random.choice([0,1,2,3]), 'speed': 2},
            {'x': 50,             'y': self.HEIGHT - 50, 'dir': random.choice([0,1,2,3]), 'speed': 2},
            {'x': self.WIDTH - 50, 'y': self.HEIGHT - 50, 'dir': random.choice([0, 1, 2, 3]), 'speed': 2},
        ]
        # Game state
        self.score = 0
        self.lives = 1
        self.powerup = False
        self.power_count = 0
        self.done = False
        self.tick = 0

    def get_player_pos(self):
        return self.player['x'], self.player['y']

    def is_wall(self, x, y):
        if y < 0 or y > self.HEIGHT-50 or x < 0 or x > self.WIDTH:
            return True
        col = int(x // self.cell_w)
        row = int(y // self.cell_h)
        return self.level[row][col] >= 3

    def can_move(self, x, y, dx, dy):

        #Разрешаем шаг, если центр спрайта после смещения
        #находится в проходимой клетке (tile < 3).
        nx = x + dx + 22   # центр по X
        ny = y + dy + 24   # центр по Y
        # превращаем в индексы клетки
        col = int(nx // self.cell_w)
        row = int(ny // self.cell_h)
        # если вылезли за карту — считаем стеной
        if col < 0 or col >= self.cols or row < 0 or row >= self.rows:
            return False
        return self.level[row][col] < 3

    def move_player(self, action):
        """
        Двигаем Pac‑Man и возвращаем награду:
        • −0.1 — за успешный шаг (поощряем минимальный путь);
        • −1.0 — если попытались шагнуть в стену (бездействие).
        """
        dx = [self.player['speed'], -self.player['speed'], 0, 0]
        dy = [0, 0, -self.player['speed'], self.player['speed']]

        if dx[action] == 0 and dy[action] == 0:  # случай «остался на месте»
            self.stuck_counter += 1
            if self.stuck_counter >= 3:
                self.stuck_counter = 0
                return -5.0
        else:
            self.stuck_counter = 0

        if self.can_move(self.player['x'], self.player['y'], dx[action], dy[action]):
            self.player['x'] += dx[action]
            self.player['y'] += dy[action]
            self.player['dir'] = action
            self.direction     = action
            return -0.05
        return -2.0

    def eat_dots(self):
        px, py = self.player['x'], self.player['y']
        cx = int((px+22) // self.cell_w)
        cy = int((py+24) // self.cell_h)
        tile = self.level[cy][cx]
        if tile == 1:
            self.level[cy][cx] = 0
            self.score += 5
            return 5
        if tile == 2:
            self.level[cy][cx] = 0
            self.score += 20
            self.powerup = True
            self.power_count = 0
            return 20
        return 0

    def move_ghosts(self):
        """
        Бродячие призраки (simple random walk):
        • НЕ целятся в Pac‑Man’а;
        • идут вперёд, пока путь свободен;
        • на перекрёстках случайно поворачивают (избегая instant‑reverse);
        • если упёрлись в стену, разворачиваются на 180° или берут любой свободный ход.
        """
        opposite = {0: 1, 1: 0, 2: 3, 3: 2}
        for g in self.ghosts:
            # текущий вектор
            dx = g.get('_dx', 0)
            dy = g.get('_dy', 0)

            # 1) можем продолжать по прежнему направлению?
            if dx or dy:
                if self.can_move(g['x'], g['y'], dx, dy):
                    g['x'] += dx
                    g['y'] += dy
                    continue  # двигаемся дальше

            # 2) нужно выбрать новое направление
            steps = [(g['speed'], 0, 0),  # right
                     (-g['speed'], 0, 1),  # left
                     (0, -g['speed'], 2),  # up
                     (0, g['speed'], 3)]  # down
            valid = [(dx, dy, d) for dx, dy, d in steps if self.can_move(g['x'], g['y'], dx, dy)]

            if not valid:
                # полностью в ловушке (не должно случиться) — стоим
                g['_dx'] = g['_dy'] = 0
                continue

            prev_dir = g.get('dir', -1)
            # избегаем мгновенного разворота, если есть другие опции
            choices = [step for step in valid if step[2] != opposite.get(prev_dir)]
            if not choices:
                choices = valid  # если только back‑track доступен

            dx, dy, d = random.choice(choices)
            g['_dx'], g['_dy'], g['dir'] = dx, dy, d
            g['x'] += dx
            g['y'] += dy

    def check_collisions(self):
        reward = 0
        pr = pygame.Rect(self.player['x']+8, self.player['y']+8, 30, 30)
        for g in self.ghosts:
            gr = pygame.Rect(g['x'], g['y'], 30, 30)
            if pr.colliderect(gr):
                if self.powerup:
                    reward += 200
                    self.score += 200
                else:
                    self.lives -= 1
                    reward -= 300
                    if self.lives <= 0:
                        self.done = True
        return reward

    def step(self, action):
        r = self.move_player(action)
        r += self.eat_dots()
        self.move_ghosts()
        r += self.check_collisions()
        # win condition
        if all(1 not in row and 2 not in row for row in self.level):
            r += 300
            self.done = True
        return self.get_state(), r, self.done

    def get_state(self):
        px, py = self.get_player_pos()
        st = [px/self.WIDTH, py/self.HEIGHT,
              self.direction/3.0, int(self.powerup),
              self.lives/1.0, self.score/1000.0]
        for g in self.ghosts:  # теперь 3 штуки
            st += [g['x'] / self.WIDTH, g['y'] / self.HEIGHT, g['dir'] / 3.0]
        return st

    def reset(self):
        self.__init__()
        return self.get_state()

    def is_done(self):
        return self.done

    def render(self, screen, frame_count):
        #отрисовка карты
        screen.fill((20,20,20))
        PI = math.pi
        for i, row in enumerate(self.level):
            for j, t in enumerate(row):
                x, y = j*self.cell_w, i*self.cell_h
                if t == 1:
                    pygame.draw.circle(screen,(250,235,127),(x+self.cell_w/2,y+self.cell_h/2),4)
                elif t == 2:
                    pygame.draw.circle(screen,(250,235,127),(x+self.cell_w/2,y+self.cell_h/2),10)
                elif t == 3:
                    pygame.draw.line(screen,(0,0,204),(x+self.cell_w/2,y),(x+self.cell_w/2,y+self.cell_h),3)
                elif t == 4:
                    pygame.draw.line(screen,(0,0,204),(x,y+self.cell_h/2),(x+self.cell_w,y+self.cell_h/2),3)
                elif t == 5:
                    pygame.draw.arc(screen,(0,0,204),[x - (self.cell_w * 0.4) - 2,y + (self.cell_h*0.5),self.cell_w,self.cell_h],0,PI/2,3)
                elif t == 6:
                    pygame.draw.arc(screen,(0,0,204),[x + (self.cell_w * 0.5),y + (self.cell_h*0.5),self.cell_w,self.cell_h],PI/2,PI,3)
                elif t == 7:
                    pygame.draw.arc(screen,(0,0,204),[x + (self.cell_w * 0.5),y - (0.4 * self.cell_h),self.cell_w,self.cell_h],PI,3*PI/2,3)
                elif t == 8:
                    pygame.draw.arc(screen,(0,0,204),[x - (self.cell_w * 0.4) - 2,y - (0.4 * self.cell_h),self.cell_w,self.cell_h],3*PI/2,2*PI,3)
                elif t == 9:
                    pygame.draw.line(screen,(250,235,127),(x,y+self.cell_h/2),(x+self.cell_w,y+self.cell_h/2),3)