import pygame
import numpy as np
import imageio
from env_game_env import GameEnv

if __name__ == "__main__":
    pygame.init()
    env = GameEnv()
    state = env.reset()
    done = False
    clock = pygame.time.Clock()

    direction = -1
    frames = []
    interrupted = False

    try:
        while not done:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    interrupted = True
                    done = True
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RIGHT:
                        direction = 0
                    elif event.key == pygame.K_LEFT:
                        direction = 1
                    elif event.key == pygame.K_UP:
                        direction = 2
                    elif event.key == pygame.K_DOWN:
                        direction = 3

            if direction in [0, 1, 2, 3] and not interrupted:
                state, reward, done, _ = env.step(direction)

            env.render()
            pygame.display.flip()

            surface = pygame.display.get_surface()
            if surface:
                frame = surface.copy()
                frame_np = pygame.surfarray.array3d(frame)
                frame_np = np.transpose(frame_np, (1, 0, 2))
                frames.append(frame_np)

            clock.tick(30)
    finally:
        if frames:
            imageio.mimsave("manual_play.gif", frames, fps=30)
            print("✅ Игра записана: manual_play.gif")
        else:
            print("⚠️ Кадры не записаны!")
